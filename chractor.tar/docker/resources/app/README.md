# Chractor App

This is the web streaming app package: supports 2x RTP video streams, 1x CAN-based 3-axis gyro/accelerometer, and 4x analog inputs/outputs (not yet configured).

### Prerequisites

This package is intended to be used with Python3, Flask, and OpenCV.

### Configuration

No configuration support at this time.

### Usage

Once booted, the device will automatically create a wifi hotspot and stream a web app which can be viewed on any tablet/pc.




