#!/bin/bash

# Note: ROS not currently available as video stream needs Python3 which ROS v1 kinetic doesnt support
#source /root/catkin_ws/devel/setup.bash
#rosrun app webstreaming.py
python3 webstreaming.py

